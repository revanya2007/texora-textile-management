import { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabase';
import { Card, CardHeader, CardTitle, CardContent } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { LoadingSpinner } from '../../components/ui/LoadingSpinner';
import { 
  FileText, 
  Truck, 
  Wallet, 
  Briefcase, 
  ArrowRight
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { 
  ResponsiveContainer, 
  XAxis, 
  YAxis, 
  Tooltip, 
  AreaChart, 
  Area 
} from 'recharts';

export default function DomesticDashboardPage() {
  const [loading, setLoading] = useState(true);
  const [deliveryTrends, setDeliveryTrends] = useState<any[]>([]);
  const [summary, setSummary] = useState({
    activeWorkOrders: 0,
    totalDeliveriesPieces: 0,
    totalWagesDisbursed: 0,
    partnerCompaniesCount: 0,
  });

  const navigate = useNavigate();

  const fetchDomesticStats = async () => {
    setLoading(true);
    try {
      // 1. Fetch Work Orders
      const { data: wo } = await supabase.from('domestic_work_orders').select('id, status');
      const activeWO = (wo || []).filter(w => w.status !== 'completed').length;

      // 2. Fetch Deliveries
      const { data: deliveries } = await supabase
        .from('domestic_deliveries')
        .select('delivery_date, quantity')
        .order('delivery_date', { ascending: true })
        .limit(10);

      const totalDelivered = (deliveries || []).reduce((acc, curr) => acc + Number(curr.quantity || 0), 0);

      const trendData = (deliveries || []).map(d => ({
        date: d.delivery_date.slice(5),
        Pieces: Number(d.quantity || 0),
      }));
      setDeliveryTrends(trendData);

      // 3. Fetch Payments
      const { data: payments } = await supabase.from('domestic_payments').select('amount');
      const totalPaid = (payments || []).reduce((acc, curr) => acc + Number(curr.amount || 0), 0);

      // 4. Fetch Companies
      const { data: companies } = await supabase.from('domestic_companies').select('id');
      const companiesCount = (companies || []).length;

      setSummary({
        activeWorkOrders: activeWO,
        totalDeliveriesPieces: totalDelivered,
        totalWagesDisbursed: totalPaid,
        partnerCompaniesCount: companiesCount,
      });

    } catch (err) {
      console.error('Error fetching domestic dashboard:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDomesticStats();
  }, []);

  if (loading) {
    return (
      <div className="p-16 flex flex-col items-center justify-center">
        <LoadingSpinner size={48} />
        <p className="mt-4 text-secondary-text font-medium">Loading domestic operations metrics...</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white p-6 rounded-xl border border-border shadow-sm">
        <div>
          <h1 className="text-2xl font-bold text-navy flex items-center gap-2">
            <FileText className="text-primary" /> Domestic Job-Work Operations
          </h1>
          <p className="text-secondary-text text-sm mt-1">
            Subcontractor work allocations, piece delivery tallies, and wage disbursals.
          </p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline" onClick={() => navigate('/domestic/work-orders')} className="text-sm">
            View Work Orders
          </Button>
          <Button onClick={() => navigate('/domestic/deliveries')} className="flex items-center gap-1 text-sm">
            <span>Record Inward</span> <ArrowRight size={15} />
          </Button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="hover:shadow-md transition-shadow">
          <CardContent className="p-5 flex items-center justify-between">
            <div>
              <p className="text-xs font-semibold text-secondary-text uppercase tracking-wider">Active Work Orders</p>
              <h3 className="text-2xl font-bold text-navy mt-1">{summary.activeWorkOrders}</h3>
              <p className="text-xs text-primary font-medium mt-0.5">Assigned to Workers</p>
            </div>
            <div className="p-3 bg-soft-mint rounded-xl text-primary"><FileText size={22} /></div>
          </CardContent>
        </Card>

        <Card className="hover:shadow-md transition-shadow">
          <CardContent className="p-5 flex items-center justify-between">
            <div>
              <p className="text-xs font-semibold text-secondary-text uppercase tracking-wider">Total Output Inward</p>
              <h3 className="text-2xl font-bold text-success mt-1">{summary.totalDeliveriesPieces.toLocaleString()} <span className="text-xs font-normal text-secondary-text">pcs</span></h3>
              <p className="text-xs text-secondary-text mt-0.5">Delivered by Tailors</p>
            </div>
            <div className="p-3 bg-emerald-50 rounded-xl text-emerald-600"><Truck size={22} /></div>
          </CardContent>
        </Card>

        <Card className="hover:shadow-md transition-shadow">
          <CardContent className="p-5 flex items-center justify-between">
            <div>
              <p className="text-xs font-semibold text-secondary-text uppercase tracking-wider">Wages Disbursed</p>
              <h3 className="text-2xl font-bold text-primary mt-1">₹{summary.totalWagesDisbursed.toLocaleString()}</h3>
              <p className="text-xs text-secondary-text mt-0.5">Settled Piece Rates</p>
            </div>
            <div className="p-3 bg-blue-50 rounded-xl text-blue-600"><Wallet size={22} /></div>
          </CardContent>
        </Card>

        <Card className="hover:shadow-md transition-shadow">
          <CardContent className="p-5 flex items-center justify-between">
            <div>
              <p className="text-xs font-semibold text-secondary-text uppercase tracking-wider">Partner Companies</p>
              <h3 className="text-2xl font-bold text-navy mt-1">{summary.partnerCompaniesCount}</h3>
              <p className="text-xs text-secondary-text mt-0.5">Contracting Brands</p>
            </div>
            <div className="p-3 bg-amber-50 rounded-xl text-amber-600"><Briefcase size={22} /></div>
          </CardContent>
        </Card>
      </div>

      {/* Delivery Chart */}
      <Card>
        <CardHeader className="border-b border-border/50 pb-3">
          <CardTitle className="text-base font-bold text-navy">Daily Inward Delivery Volume (Pieces)</CardTitle>
        </CardHeader>
        <CardContent className="pt-4">
          {deliveryTrends.length === 0 ? (
            <div className="h-64 flex flex-col items-center justify-center text-secondary-text text-sm">
              <Truck size={36} className="opacity-30 mb-2" />
              No delivery inward records yet.
            </div>
          ) : (
            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={deliveryTrends} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                  <XAxis dataKey="date" stroke="#64748B" fontSize={12} />
                  <YAxis stroke="#64748B" fontSize={12} />
                  <Tooltip contentStyle={{ backgroundColor: '#fff', borderRadius: '8px', borderColor: '#DCE8DE' }} />
                  <Area type="monotone" dataKey="Pieces" stroke="#26965D" fill="#CDE8D0" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
