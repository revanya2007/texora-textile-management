import { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabase';
import { Card, CardHeader, CardTitle, CardContent } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { LoadingSpinner } from '../../components/ui/LoadingSpinner';
import { 
  Factory, 
  ShieldCheck, 
  PackageCheck, 
  Truck,
  DollarSign, 
  Cpu, 
  TrendingUp, 
  ArrowRight
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { 
  ResponsiveContainer, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  Legend, 
  PieChart, 
  Pie, 
  Cell
} from 'recharts';

export default function ExportDashboardPage() {
  const [loading, setLoading] = useState(true);
  const [productionStats, setProductionStats] = useState<any[]>([]);
  const [qcStats, setQcStats] = useState<any[]>([]);
  const [machineStatusData, setMachineStatusData] = useState<any[]>([]);
  const [summary, setSummary] = useState({
    activeOrders: 0,
    totalOutputMeters: 0,
    acceptanceRate: 100,
    finishedGoodsAvailable: 0,
    totalInvoicedUSD: 0,
    activeMachines: 0,
    totalMachines: 0,
  });

  const navigate = useNavigate();

  const fetchDashboardData = async () => {
    setLoading(true);
    try {
      // 1. Fetch Orders Count
      const { data: orders } = await supabase.from('export_orders').select('id, status');
      const activeOrdersCount = (orders || []).filter(o => o.status !== 'closed' && o.status !== 'cancelled').length;

      // 2. Fetch Production Runs
      const { data: production } = await supabase
        .from('export_production')
        .select('production_date, planned_quantity, actual_quantity, shift')
        .order('production_date', { ascending: true })
        .limit(10);

      const prodChart = (production || []).map(p => ({
        date: p.production_date.slice(5),
        Planned: Number(p.planned_quantity || 0),
        Actual: Number(p.actual_quantity || 0),
      }));
      setProductionStats(prodChart);

      const totalOutput = (production || []).reduce((acc, curr) => acc + Number(curr.actual_quantity || 0), 0);

      // 3. Fetch Quality Inspections
      const { data: qc } = await supabase
        .from('export_quality_inspections')
        .select('inspected_quantity, accepted_quantity, rejected_quantity');

      const totalInspected = (qc || []).reduce((acc, curr) => acc + Number(curr.inspected_quantity || 0), 0);
      const totalAccepted = (qc || []).reduce((acc, curr) => acc + Number(curr.accepted_quantity || 0), 0);
      const totalRejected = (qc || []).reduce((acc, curr) => acc + Number(curr.rejected_quantity || 0), 0);
      const rate = totalInspected > 0 ? Number(((totalAccepted / totalInspected) * 100).toFixed(1)) : 100;

      setQcStats([
        { name: 'Accepted (Clearance)', value: totalAccepted || 1, color: '#26965D' },
        { name: 'Rejected (Defects)', value: totalRejected || 0, color: '#D94848' },
      ]);

      // 4. Fetch Finished Goods
      const { data: fg } = await supabase
        .from('export_finished_goods')
        .select('available_quantity');
      const totalAvailableFG = (fg || []).reduce((acc, curr) => acc + Number(curr.available_quantity || 0), 0);

      // 5. Fetch Invoices
      const { data: invoices } = await supabase
        .from('export_invoices')
        .select('total_amount');
      const totalInvoiced = (invoices || []).reduce((acc, curr) => acc + Number(curr.total_amount || 0), 0);

      // 6. Fetch Machines
      const { data: machines } = await supabase.from('export_machines').select('id, status');
      const totalMach = (machines || []).length;
      const activeMach = (machines || []).filter(m => m.status === 'active').length;
      const idleMach = (machines || []).filter(m => m.status === 'idle').length;
      const maintMach = (machines || []).filter(m => m.status === 'maintenance').length;

      setMachineStatusData([
        { name: 'Active', count: activeMach, color: '#26965D' },
        { name: 'Idle', count: idleMach, color: '#3976B8' },
        { name: 'Maintenance', count: maintMach, color: '#C58A28' },
      ]);

      setSummary({
        activeOrders: activeOrdersCount,
        totalOutputMeters: totalOutput,
        acceptanceRate: rate,
        finishedGoodsAvailable: totalAvailableFG,
        totalInvoicedUSD: totalInvoiced,
        activeMachines: activeMach,
        totalMachines: totalMach,
      });

    } catch (err) {
      console.error('Error fetching dashboard data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboardData();
  }, []);

  if (loading) {
    return (
      <div className="p-16 flex flex-col items-center justify-center">
        <LoadingSpinner size={48} />
        <p className="mt-4 text-secondary-text font-medium">Aggregating export plant metrics...</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white p-6 rounded-xl border border-border shadow-sm">
        <div>
          <h1 className="text-2xl font-bold text-navy flex items-center gap-2">
            <Factory className="text-primary" /> Export Operations Command Center
          </h1>
          <p className="text-secondary-text text-sm mt-1">
            Realtime manufacturing KPIs, plant capacity, quality metrics, and commercial dispatches.
          </p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline" onClick={() => navigate('/export/production')} className="text-sm">
            Production Floor
          </Button>
          <Button onClick={() => navigate('/export/orders')} className="flex items-center gap-1 text-sm">
            <span>View Orders</span> <ArrowRight size={15} />
          </Button>
        </div>
      </div>

      {/* Top 4 KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="hover:shadow-md transition-shadow">
          <CardContent className="p-5 flex items-center justify-between">
            <div>
              <p className="text-xs font-semibold text-secondary-text uppercase tracking-wider">Active Export Orders</p>
              <h3 className="text-2xl font-bold text-navy mt-1">{summary.activeOrders}</h3>
              <p className="text-xs text-primary font-medium mt-0.5">Under Production</p>
            </div>
            <div className="p-3 bg-soft-mint rounded-xl text-primary"><Factory size={22} /></div>
          </CardContent>
        </Card>

        <Card className="hover:shadow-md transition-shadow">
          <CardContent className="p-5 flex items-center justify-between">
            <div>
              <p className="text-xs font-semibold text-secondary-text uppercase tracking-wider">Quality Pass Rate</p>
              <h3 className="text-2xl font-bold text-success mt-1">{summary.acceptanceRate}%</h3>
              <p className="text-xs text-secondary-text mt-0.5">4-Point QC Grade A</p>
            </div>
            <div className="p-3 bg-emerald-50 rounded-xl text-emerald-600"><ShieldCheck size={22} /></div>
          </CardContent>
        </Card>

        <Card className="hover:shadow-md transition-shadow">
          <CardContent className="p-5 flex items-center justify-between">
            <div>
              <p className="text-xs font-semibold text-secondary-text uppercase tracking-wider">Finished Goods in Stock</p>
              <h3 className="text-2xl font-bold text-primary mt-1">{summary.finishedGoodsAvailable.toLocaleString()} <span className="text-xs font-normal text-secondary-text">m</span></h3>
              <p className="text-xs text-secondary-text mt-0.5">Cleared for Dispatch</p>
            </div>
            <div className="p-3 bg-blue-50 rounded-xl text-blue-600"><PackageCheck size={22} /></div>
          </CardContent>
        </Card>

        <Card className="hover:shadow-md transition-shadow">
          <CardContent className="p-5 flex items-center justify-between">
            <div>
              <p className="text-xs font-semibold text-secondary-text uppercase tracking-wider">Invoiced Receivables</p>
              <h3 className="text-2xl font-bold text-navy mt-1">${summary.totalInvoicedUSD.toLocaleString(undefined, { maximumFractionDigits: 0 })}</h3>
              <p className="text-xs text-secondary-text mt-0.5">Commercial Billing</p>
            </div>
            <div className="p-3 bg-amber-50 rounded-xl text-amber-600"><DollarSign size={22} /></div>
          </CardContent>
        </Card>
      </div>

      {/* Analytics Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Planned vs Actual Production Bar Chart */}
        <Card className="lg:col-span-2">
          <CardHeader className="border-b border-border/50 pb-3">
            <CardTitle className="text-base font-bold text-navy flex items-center gap-2">
              <TrendingUp size={18} className="text-primary" /> Daily Planned vs. Actual Output (Meters)
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-4">
            {productionStats.length === 0 ? (
              <div className="h-64 flex flex-col items-center justify-center text-secondary-text text-sm">
                <Factory size={36} className="opacity-30 mb-2" />
                No production runs recorded yet.
              </div>
            ) : (
              <div className="h-72 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={productionStats} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                    <XAxis dataKey="date" stroke="#64748B" fontSize={12} />
                    <YAxis stroke="#64748B" fontSize={12} />
                    <Tooltip contentStyle={{ backgroundColor: '#fff', borderRadius: '8px', borderColor: '#DCE8DE' }} />
                    <Legend wrapperStyle={{ paddingTop: '10px' }} />
                    <Bar dataKey="Planned" fill="#CDE8D0" radius={[4, 4, 0, 0]} />
                    <Bar dataKey="Actual" fill="#26965D" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Quality Clearance Donut Chart */}
        <Card>
          <CardHeader className="border-b border-border/50 pb-3">
            <CardTitle className="text-base font-bold text-navy flex items-center gap-2">
              <ShieldCheck size={18} className="text-primary" /> QC Inspection Yield
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-4 flex flex-col items-center justify-center">
            <div className="h-56 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={qcStats}
                    innerRadius={55}
                    outerRadius={80}
                    paddingAngle={4}
                    dataKey="value"
                  >
                    {qcStats.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip contentStyle={{ backgroundColor: '#fff', borderRadius: '8px', borderColor: '#DCE8DE' }} />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="flex gap-4 text-xs mt-2">
              <div className="flex items-center gap-1.5 font-medium text-navy">
                <span className="w-3 h-3 rounded-full bg-[#26965D]"></span> Accepted
              </div>
              <div className="flex items-center gap-1.5 font-medium text-navy">
                <span className="w-3 h-3 rounded-full bg-[#D94848]"></span> Rejected
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Machinery Status & Quick Actions Bar */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Machinery Status Card */}
        <Card className="lg:col-span-1">
          <CardHeader className="border-b border-border/50 pb-3">
            <CardTitle className="text-base font-bold text-navy flex items-center gap-2">
              <Cpu size={18} className="text-primary" /> Plant Machinery Capacity
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-4 space-y-4">
            <div className="flex justify-between items-center text-sm">
              <span className="text-secondary-text">Total Machines:</span>
              <span className="font-bold text-navy">{summary.totalMachines} units</span>
            </div>
            <div className="flex justify-between items-center text-sm">
              <span className="text-secondary-text">Active in Production:</span>
              <span className="font-bold text-success">{summary.activeMachines} units</span>
            </div>
            <div className="w-full bg-gray-100 h-3 rounded-full overflow-hidden flex">
              {machineStatusData.map((s, idx) => {
                const total = summary.totalMachines || 1;
                const widthPct = (s.count / total) * 100;
                return (
                  <div
                    key={idx}
                    style={{ width: `${widthPct}%`, backgroundColor: s.color }}
                    className="h-full"
                    title={`${s.name}: ${s.count}`}
                  ></div>
                );
              })}
            </div>
            <Button variant="outline" size="sm" onClick={() => navigate('/export/production')} className="w-full text-xs">
              Manage Machinery Floor
            </Button>
          </CardContent>
        </Card>

        {/* Quick Operational Shortcuts */}
        <Card className="lg:col-span-2">
          <CardHeader className="border-b border-border/50 pb-3">
            <CardTitle className="text-base font-bold text-navy">Quick Manufacturing Actions</CardTitle>
          </CardHeader>
          <CardContent className="p-5 grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div
              onClick={() => navigate('/export/production')}
              className="p-4 rounded-xl border border-border bg-soft-mint/20 hover:bg-soft-mint/60 cursor-pointer transition-all flex flex-col justify-between"
            >
              <div>
                <Factory size={22} className="text-primary mb-2" />
                <h4 className="font-bold text-navy text-sm">Log Production Run</h4>
                <p className="text-xs text-secondary-text mt-1">Record output and loom shifts</p>
              </div>
              <span className="text-xs font-semibold text-primary mt-3 flex items-center gap-1">Open <ArrowRight size={12} /></span>
            </div>

            <div
              onClick={() => navigate('/export/quality')}
              className="p-4 rounded-xl border border-border bg-soft-mint/20 hover:bg-soft-mint/60 cursor-pointer transition-all flex flex-col justify-between"
            >
              <div>
                <ShieldCheck size={22} className="text-emerald-600 mb-2" />
                <h4 className="font-bold text-navy text-sm">QC Fabric Audit</h4>
                <p className="text-xs text-secondary-text mt-1">Grade inspection & accept into stock</p>
              </div>
              <span className="text-xs font-semibold text-primary mt-3 flex items-center gap-1">Audit <ArrowRight size={12} /></span>
            </div>

            <div
              onClick={() => navigate('/export/dispatch')}
              className="p-4 rounded-xl border border-border bg-soft-mint/20 hover:bg-soft-mint/60 cursor-pointer transition-all flex flex-col justify-between"
            >
              <div>
                <Truck size={22} className="text-blue-600 mb-2" />
                <h4 className="font-bold text-navy text-sm">Create Dispatch</h4>
                <p className="text-xs text-secondary-text mt-1">Deduct FG stock and ship consignment</p>
              </div>
              <span className="text-xs font-semibold text-primary mt-3 flex items-center gap-1">Dispatch <ArrowRight size={12} /></span>
            </div>
          </CardContent>
        </Card>

      </div>
    </div>
  );
}
